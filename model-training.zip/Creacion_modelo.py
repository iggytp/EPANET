from elasticsearch import Elasticsearch, helpers
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, confusion_matrix, classification_report
import pickle
import os


def conectar_elasticsearch(host, user, password):
    """Establece conexión con Elasticsearch."""
    return Elasticsearch(
        host,
        basic_auth=(user, password),
        verify_certs=False
    )


def leer_indices(client, indices):
    """Lee datos desde múltiples índices de Elasticsearch y devuelve un diccionario de DataFrames."""
    dataframes = {}
    for index in indices:
        print(f"Leyendo datos del índice: {index}")
        response = client.search(index=index, scroll='2m', body={"query": {"match_all": {}}, "size": 1000})
        hits = response['hits']['hits']
        all_data = [hit["_source"] for hit in hits]
        scroll_id = response['_scroll_id']

        while len(hits) > 0:
            response = client.scroll(scroll_id=scroll_id, scroll='2m')
            hits = response['hits']['hits']
            all_data.extend([hit["_source"] for hit in hits])

        dataframes[index] = pd.DataFrame(all_data) if all_data else None
    return dataframes


def procesar_dataframe(df, festivos, timezone='Europe/Madrid'):
    """Procesa un DataFrame: convierte fechas, agrega columnas y marca festivos."""
    df['datetime'] = pd.to_datetime(df['datetime'], utc=True).dt.tz_convert(timezone)
    df['dia_semana'] = df['datetime'].dt.day_name()
    df['mes'] = df['datetime'].dt.month_name()
    festivos_set = {pd.to_datetime(f["fecha"]).date() for f in festivos}
    df['es_festivo'] = df['datetime'].dt.date.isin(festivos_set)
    df = df.drop(columns=["geo_id", "geo_name"])
    return df


def unir_dataframes(df1, df2, df3):
    """Une tres DataFrames en uno y elimina columnas innecesarias."""
    merged_df = pd.merge(df1, df2, on='datetime', how='inner')
    merged_df = pd.merge(merged_df, df3, on='datetime', how='inner')
    merged_df = merged_df.rename(columns={
        'value_x': 'demanda_prevista',
        'value_y': 'demanda_programada',
        'value': 'demanda_real'
    })
    cols_to_drop = ['datetime_utc_x', 'tz_time_x', 'dia_semana_x', 'mes_x', 'es_festivo_x',
                    'datetime_utc_y', 'tz_time_y', 'dia_semana_y', 'mes_y', 'es_festivo_y',
                    'datetime_utc', 'tz_time']
    merged_df.drop(columns=cols_to_drop, inplace=True)
    merged_df = merged_df.drop_duplicates()
    return merged_df


def agregar_componentes_temporales(df):
    """Agrega componentes temporales como año, mes, día y hora."""
    df['datetime'] = pd.to_datetime(df['datetime'])
    df['year'] = df['datetime'].dt.year
    df['month'] = df['datetime'].dt.month
    df['day'] = df['datetime'].dt.day
    df['hour'] = df['datetime'].dt.hour
    df['minute'] = df['datetime'].dt.minute
    df = df.drop(columns=['datetime', 'mes'])
    return df

def mapear_dias_semana(df):
    dias_semana_mapping = {
        'Monday': 1,
        'Tuesday': 2,
        'Wednesday': 3,
        'Thursday': 4,
        'Friday': 5,
        'Saturday': 6,
        'Sunday': 7
    }
    df['dia_semana'] = df['dia_semana'].map(dias_semana_mapping)
    return df

def convertir_festivos(df):
    df['es_festivo'] = df['es_festivo'].astype(int)
    return df


def calcular_anomalias(df):
    """Calcula las anomalías basadas en la demanda programada y la demanda real."""
    df['anomalia'] = df.apply(
        lambda row: 1 if 0.02 < abs(row['demanda_programada'] / row['demanda_real'] - 1) <= 0.05 
                    else 2 if abs(row['demanda_programada'] / row['demanda_real'] - 1) > 0.05 
                    else 0, 
        axis=1
    )
    return df

def tratar_fecha(df):
    df['fecha'] = pd.to_datetime(df[['year', 'month', 'day']])
     #Convertir la columna 'fecha' de ambos DataFrames al tipo datetime
    df['fecha'] = pd.to_datetime(df['fecha'])
    return df


def tratar_datos_clima(df):
    df['fecha'] = pd.to_datetime(df['Fecha'])
    df = df[df['Año']>2018]
    df = df[~df['Provincia'].isin(['Illes Balears', 'Las Palmas', 'Santa Cruz de Tenerife', 'Ceuta', 'Melilla'])]
    df.drop(columns=['Estación', 'Provincia'], inplace=True)
    df = df.groupby('Fecha', as_index=False).mean()
    df['Mes'] = df['Mes'].astype(int)
    df.drop(columns = ['Mes', 'Año'], inplace = True)
    df['fecha'] = pd.to_datetime(df['fecha'])
    return df

def unir_demanda_clima(demanda,clima):
    print(demanda.head())
    print(clima.head())
    demanda_df = pd.merge(demanda, clima, on='fecha', how='right')
    demanda_df.dropna(inplace=True)
    demanda_df.drop(columns = ['fecha'], inplace = True)
    return demanda_df






def entrenar_modelo(df_final):
    # --- Separar las características y las variables objetivo ---
    X = df_final.drop(columns=['demanda_programada', 'demanda_real', 'anomalia', 'demanda_prevista',  'year'])
    # Eliminar columnas no numéricas (por ejemplo, 'fecha')
    X = X.select_dtypes(include=['number'])

    y = df_final[['demanda_programada', 'demanda_real']]
    # Dividir en conjunto de entrenamiento y prueba
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Normalizar las características
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # --- Crear y entrenar el modelo Extra Trees ---
    et_model = ExtraTreesRegressor(n_estimators=100, random_state=42, n_jobs=-1)
    et_model.fit(X_train_scaled, y_train)

    # --- Predecir los valores ---
    y_pred_et = et_model.predict(X_test_scaled)
    print("Modelo entrenado")
    return et_model




def guardar_modelo(model, filename='modelo.pkl'):
    """Guarda un modelo en un archivo dentro del contenedor."""
    output_dir = "/app/output"  # Ruta fija dentro del contenedor
    os.makedirs(output_dir, exist_ok=True)  # Crear el directorio si no existe
    filepath = os.path.join(output_dir, filename)
    with open(filepath, 'wb') as file:
        pickle.dump(model, file)
    print(f"Modelo guardado en {filepath}")




def main():
    # Verificar si el modelo ya existe
    model_filename = 'modelo.pkl'
    if os.path.exists(model_filename):
        print(f"El modelo ya existe en '{model_filename}'.")
        return  # Salir de la función si el modelo ya existe

    # Parámetros de conexión
    host =  "https://pbd-proyecto:9200"
    user = "elastic"
    password = "FMMfg69DQPCTiMxG9815"
    indices = ["demanda_real_peninsula_2019_2024", "demanda_programada_peninsula_2019_2024", "demanda_prevista_peninsula_2019_2024", "clima_2013_2024"]

    # Festivos
    festivos = [
        {"fecha": "2019-01-01", "nombre": "Año Nuevo"},
        {"fecha": "2019-01-06", "nombre": "Reyes Magos"},
        {"fecha": "2019-04-18", "nombre": "Jueves Santo"},
        {"fecha": "2019-04-19", "nombre": "Viernes Santo"},
        {"fecha": "2019-04-21", "nombre": "Domingo de Resurrección"},
        {"fecha": "2019-04-22", "nombre": "Lunes de Pascua"},
        {"fecha": "2019-05-01", "nombre": "Fiesta del Trabajo"},
        {"fecha": "2019-08-15", "nombre": "Asunción de la Virgen"},
        {"fecha": "2019-10-12", "nombre": "Fiesta Nacional de España"},
        {"fecha": "2019-11-01", "nombre": "Todos los Santos"},
        {"fecha": "2019-12-06", "nombre": "Día de la Constitución"},
        {"fecha": "2019-12-08", "nombre": "Inmaculada Concepción"},
        {"fecha": "2019-12-25", "nombre": "Navidad"},

        {"fecha": "2020-01-01", "nombre": "Año Nuevo"},
        {"fecha": "2020-01-06", "nombre": "Reyes Magos"},
        {"fecha": "2020-04-09", "nombre": "Jueves Santo"},
        {"fecha": "2020-04-10", "nombre": "Viernes Santo"},
        {"fecha": "2020-04-12", "nombre": "Domingo de Resurrección"},
        {"fecha": "2020-04-13", "nombre": "Lunes de Pascua"},
        {"fecha": "2020-05-01", "nombre": "Fiesta del Trabajo"},
        {"fecha": "2020-08-15", "nombre": "Asunción de la Virgen"},
        {"fecha": "2020-10-12", "nombre": "Fiesta Nacional de España"},
        {"fecha": "2020-11-01", "nombre": "Todos los Santos"},
        {"fecha": "2020-12-06", "nombre": "Día de la Constitución"},
        {"fecha": "2020-12-08", "nombre": "Inmaculada Concepción"},
        {"fecha": "2020-12-25", "nombre": "Navidad"},

        {"fecha": "2021-01-01", "nombre": "Año Nuevo"},
        {"fecha": "2021-01-06", "nombre": "Reyes Magos"},
        {"fecha": "2021-04-01", "nombre": "Jueves Santo"},
        {"fecha": "2021-04-02", "nombre": "Viernes Santo"},
        {"fecha": "2021-04-04", "nombre": "Domingo de Resurrección"},
        {"fecha": "2021-04-05", "nombre": "Lunes de Pascua"},
        {"fecha": "2021-05-01", "nombre": "Fiesta del Trabajo"},
        {"fecha": "2021-08-15", "nombre": "Asunción de la Virgen"},
        {"fecha": "2021-10-12", "nombre": "Fiesta Nacional de España"},
        {"fecha": "2021-11-01", "nombre": "Todos los Santos"},
        {"fecha": "2021-12-06", "nombre": "Día de la Constitución"},
        {"fecha": "2021-12-08", "nombre": "Inmaculada Concepción"},
        {"fecha": "2021-12-25", "nombre": "Navidad"},

        {"fecha": "2022-01-01", "nombre": "Año Nuevo"},
        {"fecha": "2022-01-06", "nombre": "Reyes Magos"},
        {"fecha": "2022-04-14", "nombre": "Jueves Santo"},
        {"fecha": "2022-04-15", "nombre": "Viernes Santo"},
        {"fecha": "2022-04-17", "nombre": "Domingo de Resurrección"},
        {"fecha": "2022-04-18", "nombre": "Lunes de Pascua"},
        {"fecha": "2022-05-01", "nombre": "Fiesta del Trabajo"},
        {"fecha": "2022-08-15", "nombre": "Asunción de la Virgen"},
        {"fecha": "2022-10-12", "nombre": "Fiesta Nacional de España"},
        {"fecha": "2022-11-01", "nombre": "Todos los Santos"},
        {"fecha": "2022-12-06", "nombre": "Día de la Constitución"},
        {"fecha": "2022-12-08", "nombre": "Inmaculada Concepción"},
        {"fecha": "2022-12-25", "nombre": "Navidad"},

        {"fecha": "2023-01-01", "nombre": "Año Nuevo"},
        {"fecha": "2023-01-06", "nombre": "Reyes Magos"},
        {"fecha": "2023-04-06", "nombre": "Jueves Santo"},
        {"fecha": "2023-04-07", "nombre": "Viernes Santo"},
        {"fecha": "2023-04-09", "nombre": "Domingo de Resurrección"},
        {"fecha": "2023-04-10", "nombre": "Lunes de Pascua"},
        {"fecha": "2023-05-01", "nombre": "Fiesta del Trabajo"},
        {"fecha": "2023-08-15", "nombre": "Asunción de la Virgen"},
        {"fecha": "2023-10-12", "nombre": "Fiesta Nacional de España"},
        {"fecha": "2023-11-01", "nombre": "Todos los Santos"},
        {"fecha": "2023-12-06", "nombre": "Día de la Constitución"},
        {"fecha": "2023-12-08", "nombre": "Inmaculada Concepción"},
        {"fecha": "2023-12-25", "nombre": "Navidad"},

        {"fecha": "2024-01-01", "nombre": "Año Nuevo"},
        {"fecha": "2024-01-06", "nombre": "Reyes Magos"},
        {"fecha": "2024-03-28", "nombre": "Jueves Santo"},
        {"fecha": "2024-03-29", "nombre": "Viernes Santo"},
        {"fecha": "2024-03-31", "nombre": "Domingo de Resurrección"},
        {"fecha": "2024-04-01", "nombre": "Lunes de Pascua"},
        {"fecha": "2024-05-01", "nombre": "Fiesta del Trabajo"},
        {"fecha": "2024-08-15", "nombre": "Asunción de la Virgen"},
        {"fecha": "2024-10-12", "nombre": "Fiesta Nacional de España"},
        {"fecha": "2024-11-01", "nombre": "Todos los Santos"},
        {"fecha": "2024-12-06", "nombre": "Día de la Constitución"},
        {"fecha": "2024-12-08", "nombre": "Inmaculada Concepción"},
        {"fecha": "2024-12-25", "nombre": "Navidad"},
    ]
    # Leer datos
    client = conectar_elasticsearch(host, user, password)
    # Conectar a Elasticsearch


    dataframes = leer_indices(client, indices)

    # Procesar dataframes
    df_real = procesar_dataframe(dataframes['demanda_real_peninsula_2019_2024'], festivos)
    df_programada = procesar_dataframe(dataframes['demanda_programada_peninsula_2019_2024'], festivos)
    df_prevista = procesar_dataframe(dataframes['demanda_prevista_peninsula_2019_2024'], festivos)


    # Unir y procesar datos
    demanda_df = unir_dataframes(df_prevista, df_programada, df_real)
    demanda_df = agregar_componentes_temporales(demanda_df)
    demanda_df = mapear_dias_semana(demanda_df)
    demanda_df = convertir_festivos(demanda_df)
    demanda_df = calcular_anomalias(demanda_df)

    print(dataframes['clima_2013_2024'].head())
    df_clima = tratar_datos_clima(dataframes['clima_2013_2024'])
    demanda_df = tratar_fecha(demanda_df)
    demanda_df = unir_demanda_clima(demanda_df, df_clima)
    print(demanda_df.head())

    modelo = entrenar_modelo(demanda_df)

    #Guardar modelo
    guardar_modelo(modelo)


if __name__ == "__main__":
    main()
