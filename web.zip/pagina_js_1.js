document.addEventListener('DOMContentLoaded', () => {
    const mainView = document.getElementById('main-view');
    const visualizationView = document.getElementById('visualization-view');
    const predictionView = document.getElementById('prediction-view');
    const mapView = document.getElementById('map-view');
    let mapInitialized = false;

    const goToVisualization = document.getElementById('go-to-visualization');
    const goToPrediction = document.getElementById('go-to-prediction');
    const goToMap = document.getElementById('go-to-map');
    const goToHome = document.getElementById('go-to-home');

    const showView = (view) => {
        mainView.style.display = 'none';
        visualizationView.style.display = 'none';
        predictionView.style.display = 'none';
        mapView.style.display = 'none';

        if (view === 'visualization') visualizationView.style.display = 'block';
        if (view === 'prediction') predictionView.style.display = 'block';
        if (view === 'map') {
            mapView.style.display = 'block';
            if (!mapInitialized) {
                initializeMap();
                mapInitialized = true;
            }
        }
        if (view === 'home') mainView.style.display = 'block';
    };

    goToVisualization.addEventListener('click', () => showView('visualization'));
    goToPrediction.addEventListener('click', () => showView('prediction'));
    goToMap.addEventListener('click', () => showView('map'));
    goToHome.addEventListener('click', () => showView('home'));

    // Inicializar el mapa con el GeoJSON proporcionado
    const initializeMap = () => {
        const map = L.map('map').setView([40.4168, -3.7038], 6); // Coordenadas centradas en España

        // Capa base de OpenStreetMap
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        }).addTo(map);

        // URL del archivo GeoJSON con las comunidades autónomas de España
        const geoJsonUrl = 'https://data.metabolismofcities.org/library/maps/35492/view/';

        // Cargar el GeoJSON desde la URL proporcionada
        fetch(geoJsonUrl)
            .then(response => response.json())
            .then(data => {
                L.geoJson(data, {
                    style: () => ({
                        color: '#555',
                        weight: 1,
                        fillColor: '#ffde59',
                        fillOpacity: 0.7
                    }),
                    onEachFeature: (feature, layer) => {
                        layer.on('mouseover', function () {
                            this.setStyle({
                                fillColor: '#ffc107',
                                weight: 3
                            });
                            this.bindTooltip(feature.properties.NAME_1, {
                                permanent: false,
                                direction: 'center',
                                className: 'leaflet-tooltip'
                            }).openTooltip();
                        });

                        layer.on('mouseout', function () {
                            this.setStyle({
                                fillColor: '#ffde59',
                                weight: 1
                            });
                            this.unbindTooltip();
                        });
                    }
                }).addTo(map);
            })
            .catch(error => console.error('Error al cargar el archivo GeoJSON:', error));
    };

    if (location.hash === '#visualization') showView('visualization');
    else if (location.hash === '#prediction') showView('prediction');
    else if (location.hash === '#map') showView('map');
    else showView('home');
});
