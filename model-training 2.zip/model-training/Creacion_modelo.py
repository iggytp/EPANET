from elasticsearch import Elasticsearch, helpers
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, confusion_matrix, classification_report
import pickle
import os




def conectar_elasticsearch(host, user, password):
    """Establece conexión con Elasticsearch."""
    return Elasticsearch(
        host,
        basic_auth=(user, password),
        verify_certs=False
    )


def leer_indices(client, indices, batch_size=1000):
    """Lee datos desde múltiples índices de Elasticsearch y actualiza el DataFrame lote a lote."""
    dataframes = {}
    
    for index in indices:
        try:
            print(f"Iniciando lectura del índice: {index}")
            
            # Realizar la primera búsqueda
            response = client.search(index=index, scroll='2m', body={"query": {"match_all": {}}, "size": batch_size})
            hits = response['hits']['hits']
            
            # Inicializar DataFrame vacío
            df = pd.DataFrame()
            batch_count = 1

            while len(hits) > 0:
                print(f"Leyendo lote {batch_count} del índice {index}...")
                
                # Convertir el lote actual en un DataFrame
                df_batch = pd.DataFrame([hit["_source"] for hit in hits])
                
                # Concatenar el DataFrame actual con el lote
                df = pd.concat([df, df_batch], ignore_index=True)
                print(f"Tamaño del DataFrame actual: {df.shape[0]} filas.")

                # Obtener el siguiente lote
                scroll_id = response['_scroll_id']
                response = client.scroll(scroll_id=scroll_id, scroll='2m')
                hits = response['hits']['hits']
                batch_count += 1

            # Guardar el DataFrame final en el diccionario
            dataframes[index] = df if not df.empty else None
            print(f"Total de registros leídos del índice {index}: {df.shape[0]} filas.")

        except Exception as e:
            print(f"Error al procesar el índice {index}: {str(e)}")
            dataframes[index] = None

    print("Finalizada la lectura de todos los índices.")
    return dataframes






def procesar_dataframe(df, festivos, timezone='Europe/Madrid'):
    """Procesa un DataFrame: convierte fechas, agrega columnas y marca festivos."""
    df['datetime'] = pd.to_datetime(df['datetime'], utc=True).dt.tz_convert(timezone)
    df['dia_semana'] = df['datetime'].dt.day_name()
    df['mes'] = df['datetime'].dt.month_name()
    festivos_set = {pd.to_datetime(f["fecha"]).date() for f in festivos}
    df['es_festivo'] = df['datetime'].dt.date.isin(festivos_set)
    df = df.drop(columns=["geo_id", "geo_name"])
    return df


def unir_dataframes(df1, df2, df3):
    """Une tres DataFrames en uno y elimina columnas innecesarias."""
    print('Unimos los tres dataframes')
    merged_df = pd.merge(df1, df2, on='datetime', how='inner')
    merged_df = pd.merge(merged_df, df3, on='datetime', how='inner')
    merged_df = merged_df.rename(columns={
        'value_x': 'demanda_prevista',
        'value_y': 'demanda_programada',
        'value': 'demanda_real'
    })
    cols_to_drop = ['datetime_utc_x', 'tz_time_x', 'dia_semana_x', 'mes_x', 'es_festivo_x',
                    'datetime_utc_y', 'tz_time_y', 'dia_semana_y', 'mes_y', 'es_festivo_y',
                    'datetime_utc', 'tz_time']
    merged_df.drop(columns=cols_to_drop, inplace=True)
    merged_df = merged_df.drop_duplicates()
    return merged_df


def agregar_componentes_temporales(df):
    """Agrega componentes temporales como año, mes, día y hora."""
    df['datetime'] = pd.to_datetime(df['datetime'])
    df['year'] = df['datetime'].dt.year
    df['month'] = df['datetime'].dt.month
    df['day'] = df['datetime'].dt.day
    df['hour'] = df['datetime'].dt.hour
    df['minute'] = df['datetime'].dt.minute
    df = df.drop(columns=['datetime', 'mes'])
    return df

def mapear_dias_semana(df):
    dias_semana_mapping = {
        'Monday': 1,
        'Tuesday': 2,
        'Wednesday': 3,
        'Thursday': 4,
        'Friday': 5,
        'Saturday': 6,
        'Sunday': 7
    }
    df['dia_semana'] = df['dia_semana'].map(dias_semana_mapping)
    return df

def convertir_festivos(df):
    df['es_festivo'] = df['es_festivo'].astype(int)
    return df


def calcular_anomalias(df):
    """Calcula las anomalías basadas en la demanda programada y la demanda real."""
    df['anomalia'] = df.apply(
        lambda row: 1 if 0.02 < abs(row['demanda_programada'] / row['demanda_real'] - 1) <= 0.05 
                    else 2 if abs(row['demanda_programada'] / row['demanda_real'] - 1) > 0.05 
                    else 0, 
        axis=1
    )
    return df

def tratar_fecha(df):
    df['fecha'] = pd.to_datetime(df[['year', 'month', 'day']])
     #Convertir la columna 'fecha' de ambos DataFrames al tipo datetime
    df['fecha'] = pd.to_datetime(df['fecha'])
    return df


def tratar_datos_clima(df):
    # Convertir la columna 'Fecha' a datetime
    df['fecha'] = pd.to_datetime(df['Fecha'], errors='coerce')

    # Filtrar años mayores a 2018
    df = df[df['Año'] > 2018]

    # Eliminar provincias no deseadas
    if 'Provincia' in df.columns:
        df = df[~df['Provincia'].isin(['Illes Balears', 'Las Palmas', 'Santa Cruz de Tenerife', 'Ceuta', 'Melilla'])]

    # Eliminar columnas innecesarias
    columnas_irrelevantes = ['Estación', 'Provincia', 'Mes', 'Año', 'Fecha']
    df = df.drop(columns=columnas_irrelevantes, errors='ignore')

    # Seleccionar únicamente las columnas numéricas antes de agrupar
    columnas_numericas = df.select_dtypes(include=['number']).columns
    df_agg = df.groupby('fecha', as_index=False)[columnas_numericas].mean()

    print(f"Tamaño después de agrupar: {df_agg.shape[0]} filas.")
    return df_agg



def unir_demanda_clima(demanda, clima):
    print("Iniciando unión de demanda y clima...")
    print(f"Demanda tamaño: {demanda.shape}, Clima tamaño: {clima.shape}")

    # Procesar la unión en lotes si el tamaño es muy grande
    lotes = []
    clima_chunk_size = 10000  # Tamaño de cada lote para el clima

    for start in range(0, len(clima), clima_chunk_size):
        end = start + clima_chunk_size
        clima_chunk = clima.iloc[start:end]
        print(f"Procesando lote de clima: {start} a {end}")
        
        # Realizar unión con el lote actual
        merged_chunk = pd.merge(demanda, clima_chunk, on='fecha', how='right')
        merged_chunk.dropna(inplace=True)
        lotes.append(merged_chunk)

    # Concatenar todos los lotes procesados
    demanda_df = pd.concat(lotes, ignore_index=True)
    print(f"Tamaño final después de unir: {demanda_df.shape}")

    # Eliminar columna 'fecha' después de procesar
    demanda_df.drop(columns=['fecha'], inplace=True, errors='ignore')
    return demanda_df

def entrenar_modelo(df_final, batch_size=50000, max_rows=400000):
    """
    Entrena un modelo `ExtraTreesRegressor` por lotes, procesando únicamente hasta un máximo de `max_rows` registros.
    """
    # Limitar el número de filas
    df_limited = df_final.iloc[:max_rows]

    # Separar características y etiquetas
    X = df_limited.drop(columns=['demanda_programada', 'demanda_real', 'anomalia', 'demanda_prevista', 'year'])
    X = X.select_dtypes(include=['number'])
    y = df_limited[['demanda_programada', 'demanda_real']]

    # Inicializar el modelo
    et_model = ExtraTreesRegressor(n_estimators=100, random_state=42, n_jobs=-1)

    # Entrenamiento por lotes
    for start in range(0, len(X), batch_size):
        end = start + batch_size
        X_batch = X.iloc[start:end]
        y_batch = y.iloc[start:end]

        # Normalizar los datos
        scaler = StandardScaler()
        X_batch_scaled = scaler.fit_transform(X_batch)

        # Entrenar el modelo en el lote actual
        et_model.fit(X_batch_scaled, y_batch)
        print(f"Entrenado lote {start}-{end}")

    print("Modelo entrenado con los registros limitados a 400k.")
    return et_model





def guardar_modelo(model, filename='modelo.pkl'):
    """Guarda un modelo en un archivo dentro del contenedor."""
    output_dir = "/app/output"  # Ruta fija dentro del contenedor
    os.makedirs(output_dir, exist_ok=True)  # Crear el directorio si no existe
    filepath = os.path.join(output_dir, filename)
    with open(filepath, 'wb') as file:
        pickle.dump(model, file)
    print(f"Modelo guardado en {filepath}")




def main():
    # Verificar si el modelo ya existe
    model_filename = 'modelo.pkl'
    if os.path.exists(model_filename):
        print(f"El modelo ya existe en '{model_filename}'.")
        return  # Salir de la función si el modelo ya existe

    # Parámetros de conexión
    host =  "https://pbd-es01:9200"
    user = "elastic"
    password = "mi_zbMNAYYqQTXTuEAGT"
    indices = ["demanda_real_peninsula_2019_2024", "demanda_programada_peninsula_2019_2024", "demanda_prevista_peninsula_2019_2024", "clima_2013_2024"]

    # Festivos
    festivos = [
        {"fecha": "2019-01-01", "nombre": "Año Nuevo"},
        {"fecha": "2019-01-06", "nombre": "Reyes Magos"},
        {"fecha": "2019-04-18", "nombre": "Jueves Santo"},
        {"fecha": "2019-04-19", "nombre": "Viernes Santo"},
        {"fecha": "2019-04-21", "nombre": "Domingo de Resurrección"},
        {"fecha": "2019-04-22", "nombre": "Lunes de Pascua"},
        {"fecha": "2019-05-01", "nombre": "Fiesta del Trabajo"},
        {"fecha": "2019-08-15", "nombre": "Asunción de la Virgen"},
        {"fecha": "2019-10-12", "nombre": "Fiesta Nacional de España"},
        {"fecha": "2019-11-01", "nombre": "Todos los Santos"},
        {"fecha": "2019-12-06", "nombre": "Día de la Constitución"},
        {"fecha": "2019-12-08", "nombre": "Inmaculada Concepción"},
        {"fecha": "2019-12-25", "nombre": "Navidad"},

        {"fecha": "2020-01-01", "nombre": "Año Nuevo"},
        {"fecha": "2020-01-06", "nombre": "Reyes Magos"},
        {"fecha": "2020-04-09", "nombre": "Jueves Santo"},
        {"fecha": "2020-04-10", "nombre": "Viernes Santo"},
        {"fecha": "2020-04-12", "nombre": "Domingo de Resurrección"},
        {"fecha": "2020-04-13", "nombre": "Lunes de Pascua"},
        {"fecha": "2020-05-01", "nombre": "Fiesta del Trabajo"},
        {"fecha": "2020-08-15", "nombre": "Asunción de la Virgen"},
        {"fecha": "2020-10-12", "nombre": "Fiesta Nacional de España"},
        {"fecha": "2020-11-01", "nombre": "Todos los Santos"},
        {"fecha": "2020-12-06", "nombre": "Día de la Constitución"},
        {"fecha": "2020-12-08", "nombre": "Inmaculada Concepción"},
        {"fecha": "2020-12-25", "nombre": "Navidad"},

        {"fecha": "2021-01-01", "nombre": "Año Nuevo"},
        {"fecha": "2021-01-06", "nombre": "Reyes Magos"},
        {"fecha": "2021-04-01", "nombre": "Jueves Santo"},
        {"fecha": "2021-04-02", "nombre": "Viernes Santo"},
        {"fecha": "2021-04-04", "nombre": "Domingo de Resurrección"},
        {"fecha": "2021-04-05", "nombre": "Lunes de Pascua"},
        {"fecha": "2021-05-01", "nombre": "Fiesta del Trabajo"},
        {"fecha": "2021-08-15", "nombre": "Asunción de la Virgen"},
        {"fecha": "2021-10-12", "nombre": "Fiesta Nacional de España"},
        {"fecha": "2021-11-01", "nombre": "Todos los Santos"},
        {"fecha": "2021-12-06", "nombre": "Día de la Constitución"},
        {"fecha": "2021-12-08", "nombre": "Inmaculada Concepción"},
        {"fecha": "2021-12-25", "nombre": "Navidad"},

        {"fecha": "2022-01-01", "nombre": "Año Nuevo"},
        {"fecha": "2022-01-06", "nombre": "Reyes Magos"},
        {"fecha": "2022-04-14", "nombre": "Jueves Santo"},
        {"fecha": "2022-04-15", "nombre": "Viernes Santo"},
        {"fecha": "2022-04-17", "nombre": "Domingo de Resurrección"},
        {"fecha": "2022-04-18", "nombre": "Lunes de Pascua"},
        {"fecha": "2022-05-01", "nombre": "Fiesta del Trabajo"},
        {"fecha": "2022-08-15", "nombre": "Asunción de la Virgen"},
        {"fecha": "2022-10-12", "nombre": "Fiesta Nacional de España"},
        {"fecha": "2022-11-01", "nombre": "Todos los Santos"},
        {"fecha": "2022-12-06", "nombre": "Día de la Constitución"},
        {"fecha": "2022-12-08", "nombre": "Inmaculada Concepción"},
        {"fecha": "2022-12-25", "nombre": "Navidad"},

        {"fecha": "2023-01-01", "nombre": "Año Nuevo"},
        {"fecha": "2023-01-06", "nombre": "Reyes Magos"},
        {"fecha": "2023-04-06", "nombre": "Jueves Santo"},
        {"fecha": "2023-04-07", "nombre": "Viernes Santo"},
        {"fecha": "2023-04-09", "nombre": "Domingo de Resurrección"},
        {"fecha": "2023-04-10", "nombre": "Lunes de Pascua"},
        {"fecha": "2023-05-01", "nombre": "Fiesta del Trabajo"},
        {"fecha": "2023-08-15", "nombre": "Asunción de la Virgen"},
        {"fecha": "2023-10-12", "nombre": "Fiesta Nacional de España"},
        {"fecha": "2023-11-01", "nombre": "Todos los Santos"},
        {"fecha": "2023-12-06", "nombre": "Día de la Constitución"},
        {"fecha": "2023-12-08", "nombre": "Inmaculada Concepción"},
        {"fecha": "2023-12-25", "nombre": "Navidad"},

        {"fecha": "2024-01-01", "nombre": "Año Nuevo"},
        {"fecha": "2024-01-06", "nombre": "Reyes Magos"},
        {"fecha": "2024-03-28", "nombre": "Jueves Santo"},
        {"fecha": "2024-03-29", "nombre": "Viernes Santo"},
        {"fecha": "2024-03-31", "nombre": "Domingo de Resurrección"},
        {"fecha": "2024-04-01", "nombre": "Lunes de Pascua"},
        {"fecha": "2024-05-01", "nombre": "Fiesta del Trabajo"},
        {"fecha": "2024-08-15", "nombre": "Asunción de la Virgen"},
        {"fecha": "2024-10-12", "nombre": "Fiesta Nacional de España"},
        {"fecha": "2024-11-01", "nombre": "Todos los Santos"},
        {"fecha": "2024-12-06", "nombre": "Día de la Constitución"},
        {"fecha": "2024-12-08", "nombre": "Inmaculada Concepción"},
        {"fecha": "2024-12-25", "nombre": "Navidad"},
    ]
    # Leer datos
    client = conectar_elasticsearch(host, user, password)
    # Conectar a Elasticsearch


    dataframes = leer_indices(client, indices)

    # Procesar dataframes
    df_real = procesar_dataframe(dataframes['demanda_real_peninsula_2019_2024'], festivos)
    df_programada = procesar_dataframe(dataframes['demanda_programada_peninsula_2019_2024'], festivos)
    df_prevista = procesar_dataframe(dataframes['demanda_prevista_peninsula_2019_2024'], festivos)


    # Unir y procesar datos
    demanda_df = unir_dataframes(df_prevista, df_programada, df_real)
    demanda_df = agregar_componentes_temporales(demanda_df)
    demanda_df = mapear_dias_semana(demanda_df)
    demanda_df = convertir_festivos(demanda_df)
    demanda_df = calcular_anomalias(demanda_df)

    print(dataframes['clima_2013_2024'].head())
    print('entrando a tratar datos clima')
    df_clima = tratar_datos_clima(dataframes['clima_2013_2024'])
    print('entrando a tratar fecha')
    demanda_df = tratar_fecha(demanda_df)
    print('entrando a unir demanda-clima')
    demanda_df = unir_demanda_clima(demanda_df, df_clima)
    print(demanda_df.head())
    print('entrenandoModelo')
    modelo = entrenar_modelo(demanda_df)

    print('guardando modelo')
    #Guardar modelo
    guardar_modelo(modelo)


if __name__ == "__main__":
    main()
