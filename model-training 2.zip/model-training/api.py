from flask import Flask, request, jsonify
from flask_cors import CORS  # Importa Flask-CORS
import pickle
import numpy as np
import os

# Cargar el modelo entrenado desde la carpeta `/app/output`
model_filename = "/app/output/modelo.pkl"  # Ruta fija en el contenedor
if not os.path.exists(model_filename):
    raise FileNotFoundError(f"El archivo del modelo no se encontró en {model_filename}.")

with open(model_filename, 'rb') as file:
    model = pickle.load(file)

app = Flask(__name__)
CORS(app)  # Permitir solicitudes desde dominios externos (CORS)

@app.route('/')
def home():
    return "Bienvenido a la API de Predicción. Use el endpoint /predict para hacer predicciones."

@app.route('/predict', methods=['POST'])
def predict():
    """
    API para realizar predicciones.
    """
    try:
        # Obtener los datos enviados desde el cliente
        data = request.json  # Esperamos un JSON con los datos
        features = np.array(data["features"]).reshape(1, -1)  # Convertir a formato esperado por el modelo

        # Hacer la predicción
        prediction = model.predict(features)

        # Enviar la respuesta
        return jsonify({
            "success": True,
            "prediction": prediction.tolist()  # Convertir a lista para serializar en JSON
        })
    except Exception as e:
        # Manejar errores y devolver una respuesta clara al cliente
        return jsonify({
            "success": False,
            "error": str(e)
        })

if __name__ == "__main__":
    # Habilitar que la API escuche en todas las interfaces de red del contenedor
    app.run(debug=True, host="0.0.0.0", port=5000)

